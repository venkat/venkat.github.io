1. you need the latest version of python to use this code.
2. adjudge.py takes a english text file as input and calculates
counts needed to find the creativity index. it takes time as
it keeps downloading pages from wikipedia. redirect the output
of this code to a file.

python adjudge.py -i license_1.txt > result.txt

3. quantize.py reads the result.txt from standard input and does the calculation and
prints the creativity index.

python quantize.py < result.txt

4. to tweak the calculation, tweak the formula at the end of quantize.py

5. license_1.txt and 80days_3.txt are sample test files and their respective
result files are names with the suffix results.txt

6. If you need to contact the author, mail to: venki@gatech.edu
